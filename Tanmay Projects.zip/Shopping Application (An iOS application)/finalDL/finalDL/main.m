//
//  main.m
//  finalDL
//
//  Created by Tanmay Dhawale on 30/03/23.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    NSString * appDelegateClassName;
    @autoreleasepool {
        // Setup code that might create autoreleased objects goes here.
        appDelegateClassName = NSStringFromClass([AppDelegate class]);
    }
    return UIApplicationMain(argc, argv, nil, appDelegateClassName);
}

/*                       DELIVERABLES
 
 Create the demo video of the app covering following cases: NOW USER IS NOT LOGGED IN
 - User is not logged in
   -> At first user is not logged in, so application should show up login window.
 
 - User is logged in
 ->If he is already logged in then application should show up mainScreen

 - Shopping cart is empty
 ->User should see text 'Empty Cart'
 
 - Shopping cart with few products
 -> TextLabel should be disabled and we should see added products.
 
 */

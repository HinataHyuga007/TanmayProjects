//
//  ImageDownloader.m
//  ProductShopping
//
//  Created by Tanmay Dhawale on 19/03/23.
//

#import "ImageDownloader.h"

@implementation ImageDownloader

- (void)imageForGivenURL:(NSURL *)url completion:(void (^)(UIImage *))completion {
    NSURLSessionDataTask *task = [[NSURLSession sharedSession] dataTaskWithURL:url completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        UIImage *image = nil;
        if (data) {
            image = [UIImage imageWithData:data];
            
        }
        completion(image);
    }];
    [task resume];
}
@end


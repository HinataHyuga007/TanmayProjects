//
//  CustomCell.h
//  ProductShopping
//
//  Created by Tanmay Dhawale on 19/03/23.
//

#import <UIKit/UIKit.h>

@interface CustomCell : UITableViewCell

@property (nonatomic, strong) UIImageView *productImageView;
@property (nonatomic, strong) UILabel *priceLabel;
@property (nonatomic, strong) UILabel *productNameLabel;
@property (nonatomic, strong) UILabel *descriptionLabel;
@property (nonatomic, strong) UILabel *productCategoryLabel;
@property (nonatomic, strong) UILabel *productBrandLabel;
@property (nonatomic, strong) UIButton  *additionCart;
@property (nonatomic, strong) NSMutableArray *titlesArray;
/*
@property (nonatomic, strong) NSMutableArray *productTitlesArray;
@property (nonatomic, strong) NSMutableArray *productPriceArray;

@property (nonatomic, strong) NSMutableArray *productDesriptionsArray;
@property (nonatomic, strong) NSMutableArray *productCategoriesArray;*/
//@property (nonatomic, assign) BOOL isAccesibilityElement;
@end

//
//  SecondViewController.m
//  DeepLinking
//
//  Created by Tanmay Dhawale on 30/03/23.
//

#import "SceneDelegate.h"
#import <Foundation/Foundation.h>
#import"SecondViewController.h"
#import"FirstViewController.h"

@interface SecondViewController ()
@property (nonatomic, strong) NSMutableArray *productsPushed;

@property(nonatomic, strong) NSMutableArray *pricesPushed;
@property (nonatomic, strong) UILabel *titleLabel;
@end

@implementation SecondViewController


- (void)viewDidLoad {
        [super viewDidLoad];
    
    
        [self setTitle:@"My Cart"];
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    self.productsPushed = [defaults objectForKey:@"Titles"];
    self.pricesPushed = [defaults objectForKey:@"Prices"];
    NSArray *prices = [defaults objectForKey:@"Prices"];
    self.view.backgroundColor = UIColor.yellowColor;
        self.titleLabel = [[UILabel alloc] init];
        [self.titleLabel setFont:[UIFont systemFontOfSize:24]];
        [self.titleLabel setTextColor:[UIColor whiteColor]];
        [self.titleLabel setBackgroundColor:[UIColor colorWithRed:0.14 green:0.56 blue:1.00 alpha:1.00]];
        [self.titleLabel setTextAlignment:NSTextAlignmentCenter];
    if(self.pricesPushed.count == 0){
        [self.titleLabel setText:@"Cart Empty"];
    }
    else{
        /*
        NSInteger totalPrice = 0;
        for(NSString *price in prices){
            NSString *string = price;
            float number = [string floatValue];
            int stringDouble = [price intValue];
            NSLog(@"totlaprice %ld",(long)number);
            totalPrice+=stringDouble;
        }
        NSString *string = [NSString stringWithFormat:@"%d", totalPrice];
        [self.titleLabel setText:string];
        */
        self.titleLabel.hidden = YES;
    }
    
    [self.titleLabel setTranslatesAutoresizingMaskIntoConstraints:NO];
        [self.view addSubview:self.titleLabel];
    [self.view setBackgroundColor:UIColor.whiteColor];
        // Create a button to browse products
        UIButton *browseButton = [UIButton buttonWithType:UIButtonTypeSystem];
        [browseButton setTitle:@"Browse Products" forState:UIControlStateNormal];
        [browseButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [browseButton setBackgroundColor:[UIColor colorWithRed:0.99 green:0.47 blue:0.47 alpha:1.00]];
        [browseButton setTranslatesAutoresizingMaskIntoConstraints:NO];
        [self.view addSubview:browseButton];
        
        // Set up AutoLayout constraints for the label and button
        UILayoutGuide *safeArea = [self.view safeAreaLayoutGuide];
        [self.titleLabel.topAnchor constraintEqualToAnchor:safeArea.topAnchor constant:16].active = YES;
        [self.titleLabel.leadingAnchor constraintEqualToAnchor:safeArea.leadingAnchor constant:16].active = YES;
        [self.titleLabel.trailingAnchor constraintEqualToAnchor:safeArea.trailingAnchor constant:-16].active = YES;
        [self.titleLabel.heightAnchor constraintEqualToConstant:50].active = YES;
        
        [browseButton.topAnchor constraintEqualToAnchor:self.titleLabel.bottomAnchor constant:16].active = YES;
        [browseButton.centerXAnchor constraintEqualToAnchor:safeArea.centerXAnchor].active = YES;
        [browseButton.widthAnchor constraintEqualToConstant:200].active = YES;
        [browseButton.heightAnchor constraintEqualToConstant:50].active = YES;
    
    
    [browseButton addTarget:self action:@selector(browseButtonTapped) forControlEvents:UIControlEventTouchUpInside];

        
        // Set up table view
        self.tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
        self.tableView.translatesAutoresizingMaskIntoConstraints = NO;
        self.tableView.dataSource = self;
        self.tableView.delegate = self;
        [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"Cell"];
        [self.view addSubview:self.tableView];
        
        // Set up Auto Layout constraints for table view
        [NSLayoutConstraint activateConstraints:@[
            [self.tableView.topAnchor constraintEqualToAnchor:browseButton.bottomAnchor constant:8],
            [self.tableView.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:8],
            [self.tableView.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-8],
            [self.tableView.bottomAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.bottomAnchor constant:-8]
        ]];
    
}

- (void)viewWillAppear:(BOOL)animated{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    self.productsPushed = [defaults objectForKey:@"Titles"];
    self.pricesPushed = [defaults objectForKey:@"Prices"];
    int totalCount = (int)self.pricesPushed.count ;
    dispatch_async(dispatch_get_main_queue(), ^{
        if(totalCount == 0){
            [self.titleLabel setText:@"Cart Empty"];
        }
        else{
            int totalPrice = 0;
            for(NSString *price in self.pricesPushed){
                NSLog(@"sehfkshf");
                int stringDouble = [price intValue];
                totalPrice+=stringDouble;
                NSString *string = [NSString stringWithFormat:@"%d", totalPrice];
                [self.titleLabel setText:string];
            }
        }
        [self.tableView reloadData];
    });
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
        NSArray *titles = [defaults objectForKey:@"Titles"];
    
    return titles.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];
        
        
        
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSArray *titles = [defaults objectForKey:@"Titles"];
    NSArray *prices = [defaults objectForKey:@"Prices"];
    //UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];
    NSString *price = [prices objectAtIndex:indexPath.row];
    NSString *title = [titles objectAtIndex:indexPath.row];
    
    NSString *Appendingtring = [[[title stringByAppendingString:@"             "]stringByAppendingString: @"Price : "]stringByAppendingString:price];
    cell.textLabel.text =Appendingtring ;

    return cell;
}


- (void)browseButtonTapped {
    UITabBarController *tbar = self.tabBarController;
    tbar.selectedIndex = 0;
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSArray *titles = [defaults objectForKey:@"Titles"];
        
        // Log the titles to the console
        NSLog(@"In newVC:");
        for (NSString *title in titles) {
            NSLog(@"hhhh%@", title);
    }
}
@end

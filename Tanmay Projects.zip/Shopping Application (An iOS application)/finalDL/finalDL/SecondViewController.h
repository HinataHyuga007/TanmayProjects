//
//  SecondViewController.h
//  DeepLinking
//
//  Created by Tanmay Dhawale on 30/03/23.
//

#import <UIKit/UIKit.h>
@interface SecondViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>

@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSArray *productsArray;


@end


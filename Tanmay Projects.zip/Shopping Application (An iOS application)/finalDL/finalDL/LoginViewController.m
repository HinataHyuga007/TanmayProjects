//
//  ViewController.m
//  demoLogin
//
//  Created by Tanmay Dhawale on 10/04/23.
//

#import "LoginViewController.h"
#import "FirstViewController.h"
#import "SecondViewController.h"
#import "ThirdViewController.h"

@interface LoginViewController ()

@end

@implementation LoginViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    int ms = [[NSUserDefaults standardUserDefaults]valueForKey:@"background"];
    if(ms == 1){
        NSLog(@"Hello");
        self.view.backgroundColor = UIColor.greenColor;
    }
    self.usernameField = [[UITextField alloc] initWithFrame:CGRectMake(20, 100, 280, 30)];
    self.usernameField.placeholder = @"Username";
    self.usernameField.borderStyle = UITextBorderStyleRoundedRect;
    [self.view addSubview:self.usernameField];
    
    self.passwordField = [[UITextField alloc] initWithFrame:CGRectMake(20, 150, 280, 30)];
    self.passwordField.placeholder = @"Password";
    self.passwordField.borderStyle = UITextBorderStyleRoundedRect;
    self.passwordField.secureTextEntry = YES;
    [self.view addSubview:self.passwordField];
    
    self.loginButton = [[UIButton alloc] initWithFrame:CGRectMake(20, 200, 280, 30)];
    [self.loginButton setTitle:@"Login" forState:UIControlStateNormal];
    [self.loginButton addTarget:self action:@selector(loginButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
    [self.loginButton setBackgroundColor:UIColor.blueColor];
    [self.view addSubview:self.loginButton];
}


- (void)viewDidLayoutSubviews{
    [super viewDidLayoutSubviews];
    NSLog(@"Passed");
}
- (void)loginButtonPressed:(id)sender {
    NSDictionary *credentials = [NSDictionary dictionaryWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"UserCredentails" ofType:@"plist"]];
    NSString *password = [credentials objectForKey:self.usernameField.text];
    if ([self.passwordField.text isEqualToString:password]) {
        // Login successful
        [[NSUserDefaults standardUserDefaults] setInteger:1 forKey:@"background"];
        //[defaults synchronize];
        NSLog(@"Success");
        self.tabBarController = [[UITabBarController alloc] init];
        FirstViewController *homeViewCOntroller = [[FirstViewController alloc]init];
        SecondViewController *myCartViewController = [[SecondViewController alloc]init];
        ThirdViewController *accountViewController = [[ThirdViewController alloc]init];
        UIFont *font = [UIFont systemFontOfSize:18.0];
        NSDictionary *attributes = @{ NSFontAttributeName: font };
        [[UITabBarItem appearance] setTitleTextAttributes:attributes forState:UIControlStateNormal];
        [self.tabBarController setViewControllers:@[ homeViewCOntroller, myCartViewController, accountViewController ]];
        self.tabBarController.tabBar.backgroundColor = UIColor.whiteColor;
        
        [[self.tabBarController.tabBar.items objectAtIndex:0]setTitle:@"Home"];
        [[self.tabBarController.tabBar.items objectAtIndex:1]setTitle:@"My Cart"];
        [[self.tabBarController.tabBar.items objectAtIndex:2]setTitle:@"Account"];
        _tabBarController.selectedIndex = 0;
        _tabBarController.edgesForExtendedLayout = UIRectEdgeAll;
        [self presentViewController:_tabBarController animated:NO completion:nil];
    } else {
        // Login failed
        UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Login Failed" message:@"Invalid username or password." preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"OK" style:UIAlertActionStyleDefault handler:nil];
        [alert addAction:okAction];
        [self presentViewController:alert animated:YES completion:nil];
    }
}


@end

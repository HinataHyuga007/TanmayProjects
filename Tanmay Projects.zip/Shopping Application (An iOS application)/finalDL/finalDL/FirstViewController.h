//
//  FirstViewController.h
//  DeepLinking
//
//  Created by Tanmay Dhawale on 30/03/23.
//
#import <UIKit/UIKit.h>

@interface FirstViewController :UIViewController <UITableViewDelegate, UITableViewDataSource, UITabBarControllerDelegate>
    @property (nonatomic, strong) NSMutableArray *data;
@property (nonatomic, strong) NSMutableArray *titlesArray;

@property (nonatomic, strong) NSMutableArray *priceArray;
- (void)addTitle:(UIButton *)sender;
@end

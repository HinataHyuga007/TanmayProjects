//
//  ViewController.h
//  ProductShopping
//
//  Created by Tanmay Dhawale on 19/03/23.
//

#import <UIKit/UIKit.h>

@interface ViewController :UIViewController <UITableViewDelegate, UITableViewDataSource, UITabBarControllerDelegate>
    @property (nonatomic, strong) NSMutableArray *data;

@end


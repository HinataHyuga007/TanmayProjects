//
//  ImageDownloader.h
//  ProductShopping
//
//  Created by Tanmay Dhawale on 19/03/23.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#import <UIKit/UIKit.h>

@interface ImageDownloader : NSObject
@property (nonatomic, strong) NSMutableArray *data;
-(void)imageForGivenURL:(NSURL *)url completion:(void (^)(UIImage *))completion;
@end


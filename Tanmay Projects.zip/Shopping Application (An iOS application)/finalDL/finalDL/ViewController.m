//
//  ViewController.m
//  ProductShopping
//
//  Created by Tanmay Dhawale on 19/03/23.
//

#import "ViewController.h"
#import "CustomCell.h"
#import "Model.h"
#import"ImageDownloader.h"

#import "NSArray+Sorting.h"
@interface ViewController () <UITableViewDelegate, UITableViewDataSource>
@property (nonatomic, strong) UIImage *downloadedImage;
@property(nonatomic,strong) NSMutableArray *productsArray;
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) UISlider *priceSlider;
@property(nonatomic, strong)NSMutableArray *totalProducts;
@end

@implementation ViewController
- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    self.tableView.isAccessibilityElement = NO;
    [self setModelData];
    self.view.backgroundColor = [UIColor whiteColor];
    UIButton *sortByPriceButton = [UIButton buttonWithType:UIButtonTypeSystem];
    self.priceSlider = [[UISlider alloc]init];
    self.totalProducts = [[NSMutableArray alloc]init];
    UILabel *minLAbel = [[UILabel alloc]init];
    UILabel *maxLabel = [[UILabel alloc]init];
    [self.view addSubview:minLAbel];
    [self.view addSubview:maxLabel];
    UILabel *sliderValueLabel = [[UILabel alloc]init];
    self.priceSlider.minimumValue = 0;
    self.priceSlider.maximumValue = 2000;
    self.priceSlider.translatesAutoresizingMaskIntoConstraints = NO;
    [sortByPriceButton setTitle:@"Sort by Price" forState:UIControlStateNormal];
    sortByPriceButton.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:sortByPriceButton];
    [self.view addSubview:self.priceSlider];
    sortByPriceButton.tag = 1;
    sortByPriceButton.backgroundColor = UIColor.blackColor;
    UIButton *sortByCattegoryButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [sortByCattegoryButton setTitle:@"Sort Category" forState:UIControlStateNormal];
    sortByCattegoryButton.tag = 2;
    sortByCattegoryButton.backgroundColor = UIColor.blackColor;
    sortByCattegoryButton.translatesAutoresizingMaskIntoConstraints = NO;
    minLAbel.translatesAutoresizingMaskIntoConstraints = NO;
    maxLabel.translatesAutoresizingMaskIntoConstraints = NO;
    minLAbel.text = @"0";
    maxLabel.text = @"2000";
    [self.view addSubview:sortByCattegoryButton];
    [sortByPriceButton addTarget:self action:@selector(buttonTapped:) forControlEvents:UIControlEventTouchUpInside];
    [sortByCattegoryButton addTarget:self action:@selector(buttonTapped:) forControlEvents:UIControlEventTouchUpInside];
    sliderValueLabel.translatesAutoresizingMaskIntoConstraints = NO;
    sliderValueLabel.backgroundColor = UIColor.redColor;
    [self.view addSubview:sliderValueLabel];
    [NSLayoutConstraint activateConstraints:@[
        [self.priceSlider.leadingAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.leadingAnchor constant:50],
        [self.priceSlider.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor],
        [self.priceSlider.heightAnchor constraintEqualToAnchor:sortByPriceButton.heightAnchor],
        [self.priceSlider.trailingAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.trailingAnchor constant:-50],
        [sortByPriceButton.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor],
        [sortByPriceButton.topAnchor constraintEqualToAnchor:sliderValueLabel.bottomAnchor constant:20],
        [sortByPriceButton.widthAnchor constraintEqualToConstant:self.view.frame.size.width/2],
        [sliderValueLabel.topAnchor constraintEqualToAnchor:self.priceSlider.bottomAnchor constant:5],
        [sliderValueLabel.bottomAnchor constraintEqualToAnchor:self.priceSlider.bottomAnchor constant:25],
        [sortByCattegoryButton.leadingAnchor constraintEqualToAnchor:sortByPriceButton.trailingAnchor constant:20],
        [sortByCattegoryButton.topAnchor constraintEqualToAnchor:sortByPriceButton.topAnchor],
        [sortByCattegoryButton.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor],
        [minLAbel.leadingAnchor constraintEqualToAnchor:self.priceSlider.leadingAnchor constant:-20],
        [minLAbel.trailingAnchor constraintEqualToAnchor:self.priceSlider.leadingAnchor constant:-5],
        [minLAbel.topAnchor constraintEqualToAnchor:self.priceSlider.topAnchor],
        [minLAbel.bottomAnchor constraintEqualToAnchor:self.priceSlider.bottomAnchor],
        
        [maxLabel.leadingAnchor constraintEqualToAnchor:self.priceSlider.trailingAnchor constant:5],
        [maxLabel.trailingAnchor constraintEqualToAnchor:self.priceSlider.trailingAnchor constant:50],
        [maxLabel.topAnchor constraintEqualToAnchor:self.priceSlider.topAnchor],
        [maxLabel.bottomAnchor constraintEqualToAnchor:self.priceSlider.bottomAnchor],
    ]];
    
    self.tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
    
    
    self.tableView.translatesAutoresizingMaskIntoConstraints = NO;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    self.tableView.backgroundColor = [UIColor clearColor];
    CGFloat spacing = 10.0; // Set the spacing here
    self.tableView.contentInset = UIEdgeInsetsMake(spacing, 0, spacing, 0);
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    
    [self.view addSubview:self.tableView];
    [self.tableView registerClass:[CustomCell class] forCellReuseIdentifier:@"CustomCell"];
    [NSLayoutConstraint activateConstraints:@[
        [self.tableView.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor],
        [self.tableView.topAnchor constraintEqualToAnchor:sortByPriceButton.bottomAnchor constant:20],
        [self.tableView.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor],
        [self.tableView.bottomAnchor constraintEqualToAnchor:self.view.bottomAnchor constant:-100]
    ]];

    //accessibility enabled
    minLAbel.isAccessibilityElement = YES;
    minLAbel.accessibilityLabel = @"minimum slider value: 0";
    minLAbel.accessibilityHint = @"minimum value for price";
    maxLabel.isAccessibilityElement = YES;
    maxLabel.accessibilityLabel = @"maximum slider value: 2000";
    maxLabel.accessibilityHint = @"maximum value for price";
    self.priceSlider.isAccessibilityElement = YES;
    self.priceSlider.accessibilityLabel = @"slider for filtering price";
    self.priceSlider.accessibilityHint = @"slide through to filter price";
    sortByPriceButton.isAccessibilityElement = YES;
    sortByPriceButton.accessibilityLabel = @"Sort Price";
    sortByCattegoryButton.isAccessibilityElement = YES;
    sortByPriceButton.accessibilityValue = @"Click me to sort by selected price range";
    sortByCattegoryButton.accessibilityValue = @"Click me to sort by category";
    minLAbel.adjustsFontForContentSizeCategory = YES;
    maxLabel.adjustsFontForContentSizeCategory = YES;
    sortByPriceButton.titleLabel.adjustsFontForContentSizeCategory = YES;
    sortByCattegoryButton.titleLabel.adjustsFontForContentSizeCategory = YES;
    minLAbel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
    maxLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
    sortByPriceButton.titleLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
    sortByCattegoryButton.titleLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
    
}

-(void)setModelData {
    NSURLRequest *urlRequest = [NSURLRequest requestWithURL:[NSURL URLWithString:@"https://dummyjson.com/products"]];
    NSURLSession *session = [NSURLSession sharedSession];
    NSURLSessionDataTask *dataTask = [session dataTaskWithRequest:urlRequest completionHandler:^(NSData *JSONdata, NSURLResponse *response, NSError *error) {
        if(error){
            NSLog(@"Error while fetching JSON data");
        }
        else{
            NSDictionary *jsonDict = [NSJSONSerialization JSONObjectWithData:JSONdata options:kNilOptions error:nil];
            NSMutableArray *allProducts = [jsonDict objectForKey:@"products"];
            for (NSDictionary *productDict in allProducts) {
                Model *product = [[Model alloc]init];
                product.productId = [productDict objectForKey:@"id"];
                product.productBrand = [productDict objectForKey:@"brand"];
                product.price = [productDict objectForKey:@"price"];
                product.productDescription = [productDict objectForKey:@"description"];
                product.productCategory = [productDict objectForKey:@"category"];
                product.productRating = [productDict objectForKey:@"rating"];
                product.productThumbnail = [productDict objectForKey:@"thumbnail"];
                product.productTitle = [productDict objectForKey:@"title"];
                product.images = [productDict objectForKey:@"images"];
                [self.totalProducts addObject:product];
            }
            self.productsArray = self.totalProducts;
            dispatch_async(dispatch_get_main_queue(), ^{
                [self.tableView reloadData];
            });
        }
    }];
    [dataTask resume];
}



-(void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UIViewController *)viewController {
    if ([viewController isKindOfClass:[UIViewController class]]) {
    // Display the OtherViewController
    UIViewController *otherViewController = [[UIViewController alloc] init];
    [self.navigationController pushViewController:otherViewController animated:YES]; // Assuming you're using a navigation controller
    }
}
-(void)buttonTapped:(UIButton *)sender{
    if(sender.tag == 1){
    self.productsArray = self.totalProducts;
    NSMutableArray *productArray = [NSMutableArray array];
    int sliderValue = self.priceSlider.value;
        self.priceSlider.accessibilityValue =  [NSString stringWithFormat:@"$%d", sliderValue];
    NSLog(@"sliderValue: %d",sliderValue);
    for(Model *productmodel in self.productsArray){
        
        if([productmodel.price integerValue] < sliderValue){
            [productArray addObject:productmodel];
        }
    }
    self.productsArray = productArray;
    NSArray *sortedProducts = [self.productsArray sortedArrayByProductPrice];
    self.productsArray = sortedProducts;
    [self.tableView reloadData];
    }
    else if (sender.tag == 2){
        self.productsArray = self.totalProducts;
        [self.productsArray sortedArrayByProductCategory];
        [self.tableView reloadData];
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 200;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.productsArray.count;
    //return 2;
}

- (nonnull UITableViewCell *)tableView:(nonnull UITableView *)tableView cellForRowAtIndexPath:(nonnull NSIndexPath *)indexPath {
    CustomCell *cell = (CustomCell *)[tableView dequeueReusableCellWithIdentifier:@"CustomCell"];
    if(cell == nil){
        cell = [[CustomCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"CustomCell"];
    }
    
    Model *productObject = [self.productsArray objectAtIndex:indexPath.row];
    NSString *imageLink = productObject.images.firstObject;
    NSURL *imageURL = [NSURL URLWithString:imageLink];
    ImageDownloader *imageDownloader = [[ImageDownloader alloc] init];
    [imageDownloader imageForGivenURL:imageURL completion:^(UIImage *image){
        dispatch_async(dispatch_get_main_queue(), ^{
            CGSize newSize = CGSizeMake(125, 140);
            UIGraphicsBeginImageContextWithOptions(newSize, NO, 0.0);
            [image drawInRect:CGRectMake(0, 0, newSize.width, newSize.height)];
            UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
            UIGraphicsEndImageContext();
            cell.imageView.image = newImage;
        });
    }];
    cell.productNameLabel.text = productObject.productTitle;
    cell.priceLabel.text = [NSString stringWithFormat:@"$%@", productObject.price];
    cell.descriptionLabel.text = productObject.productDescription;
    cell.backgroundColor = [UIColor lightGrayColor];
    cell.productCategoryLabel.text  = productObject.productCategory;
    cell.clipsToBounds = YES;
    cell.accessibilityValue = [[cell.productNameLabel.text stringByAppendingString:cell.productCategoryLabel.text]stringByAppendingString:cell.priceLabel.text];
    cell.productNameLabel.accessibilityLabel = cell.productNameLabel.text;
    cell.productNameLabel.accessibilityTraits = UIAccessibilityTraitStaticText;
    cell.accessibilityHint = @"Product Details";
    cell.priceLabel.accessibilityLabel = cell.priceLabel.text;
    cell.priceLabel.accessibilityTraits = UIAccessibilityTraitStaticText;
    cell.accessibilityIdentifier = @"Table Cell";

    cell.productCategoryLabel.accessibilityLabel = cell.productCategoryLabel.text;
    cell.productCategoryLabel.accessibilityTraits = UIAccessibilityTraitStaticText;
    //this will provide Voice Over in specific order
    cell.accessibilityElements = @[cell.productNameLabel, cell.priceLabel, cell.productCategoryLabel];

    cell.isAccessibilityElement = YES;

    return cell;
}
@end


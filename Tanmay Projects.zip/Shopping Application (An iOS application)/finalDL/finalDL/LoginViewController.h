//
//  ViewController.h
//  demoLogin
//
//  Created by Tanmay Dhawale on 10/04/23.
//

#import <UIKit/UIKit.h>

@interface LoginViewController : UIViewController
@property (strong, nonatomic) UITabBarController *tabBarController;
@property (nonatomic, strong) UITextField *usernameField;
@property (nonatomic, strong) UITextField *passwordField;
@property (nonatomic, strong) UIButton *loginButton;

- (void)loginButtonPressed:(id)sender;

@end


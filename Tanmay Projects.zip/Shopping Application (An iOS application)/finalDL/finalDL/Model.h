//
//  Product.h
//  BlockDemo
//
//  Created by Vedant Shirude on 17/03/23.
//

#import <Foundation/Foundation.h>


@interface Model:NSObject
    @property(strong, nonatomic) NSString *productId;
    @property(strong, nonatomic) NSString *productTitle;
    @property(strong, nonatomic) NSString *productDescription;
    @property(strong, nonatomic) NSString *productCategory;
    @property(strong, nonatomic) NSString *productRating;
    @property(strong, nonatomic) NSString *productThumbnail;
    @property(strong, nonatomic) NSString *productBrand;
    @property(nonatomic) float productPrice;
    @property(strong, nonatomic)  NSString *price;
    @property(strong, nonatomic) NSMutableArray<NSString*>*images;
@end


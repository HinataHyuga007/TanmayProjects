//
//  SceneDelegate.m
//  finalDL
//
//  Created by Tanmay Dhawale on 30/03/23.
//

#import "SceneDelegate.h"
#import "FirstViewController.h"
#import "SecondViewController.h"
#import "ThirdViewController.h"
#import "LoginViewController.h"
@interface SceneDelegate ()


@end
static NSString *const deeplink = @"home";
static NSString *const mycartHost = @"mycart";
static NSString *const accountHost = @"profile";

@implementation SceneDelegate

- (void)scene:(UIScene *)scene willConnectToSession:(UISceneSession *)session options:(UISceneConnectionOptions *)connectionOptions {
    
    UIWindowScene *windowScene = (UIWindowScene *)scene;
    self.window = [[UIWindow alloc]initWithWindowScene: windowScene];
     BOOL isFirstVCAlreadyPushed = [[NSUserDefaults standardUserDefaults] boolForKey:@"isFirstVCAlreadyPushed"];
     
     if (isFirstVCAlreadyPushed) {
     [self setupTabBarVC];
     NSURL *url = connectionOptions.URLContexts.allObjects.firstObject.URL;
     NSLog(@"#URL:%@",url);
     int tabBarSelectedIndex = 0;
     if([url.host isEqualToString:deeplink]){
         tabBarSelectedIndex = 0;
     }
     else if([url.host isEqualToString:mycartHost]){
         tabBarSelectedIndex = 1;
     }
     else if([url.host isEqualToString:accountHost]){
         tabBarSelectedIndex = 2;
     }
     else{
         NSLog(@"Following URL should be matched with existing: %@",url);
     }
     _tabBarController.selectedIndex = tabBarSelectedIndex;;
     self.window.rootViewController = _tabBarController;
     }
     else {
     [self setupTabBarVCVC];
     _tabBarController.selectedIndex = 0;
     self.window.rootViewController = _tabBarController;
         [[NSUserDefaults standardUserDefaults] setBool:YES forKey:@"isFirstVCAlreadyPushed"];
        
     }
     /*
    NSURL *url = connectionOptions.URLContexts.allObjects.firstObject.URL;
    NSLog(@"#URL:%@",url);
    int tabBarSelectedIndex = 0;
    if([url.host isEqualToString:deeplink]){
        tabBarSelectedIndex = 0;
    }
    else if([url.host isEqualToString:mycartHost]){
        tabBarSelectedIndex = 1;
    }
    else if([url.host isEqualToString:accountHost]){
        tabBarSelectedIndex = 2;
    }
    else{
        NSLog(@"Following URL should be matched with existing: %@",url);
    }
    _tabBarController.selectedIndex = tabBarSelectedIndex;;
    self.window.rootViewController = _tabBarController;
    */
    [self.window makeKeyAndVisible];
}
- (void)setupTabBarVC{
    self.tabBarController = [[UITabBarController alloc] init];
    FirstViewController *homeViewCOntroller = [[FirstViewController alloc]init];
    SecondViewController *myCartViewController = [[SecondViewController alloc]init];
    ThirdViewController *accountViewController = [[ThirdViewController alloc]init];
    UIFont *font = [UIFont systemFontOfSize:18.0];
    NSDictionary *attributes = @{ NSFontAttributeName: font };
    [[UITabBarItem appearance] setTitleTextAttributes:attributes forState:UIControlStateNormal];
    [self.tabBarController setViewControllers:@[ homeViewCOntroller, myCartViewController, accountViewController ]];
    self.tabBarController.tabBar.backgroundColor = UIColor.whiteColor;
    
    [[self.tabBarController.tabBar.items objectAtIndex:0]setTitle:@"Home"];
    [[self.tabBarController.tabBar.items objectAtIndex:1]setTitle:@"My Cart"];
    [[self.tabBarController.tabBar.items objectAtIndex:2]setTitle:@"Account"];
}
- (void)setupTabBarVCVC{
    self.tabBarController = [[UITabBarController alloc] init];
    LoginViewController *homeViewCOntroller = [[LoginViewController alloc]init];
    UIFont *font = [UIFont systemFontOfSize:18.0];
    NSDictionary *attributes = @{ NSFontAttributeName: font };
    [[UITabBarItem appearance] setTitleTextAttributes:attributes forState:UIControlStateNormal];
    [self.tabBarController setViewControllers:@[homeViewCOntroller]];
    self.tabBarController.tabBar.backgroundColor = UIColor.whiteColor;
    
    [[self.tabBarController.tabBar.items objectAtIndex:0]setTitle:@"LoginScreen"];
}
-(void) scene: (UIScene*)scene openURLContexts:(NSSet<UIOpenURLContext *> *)URLContexts{
    NSURL *url = URLContexts.allObjects.firstObject.URL;
    NSLog(@"#URL:%@",url);
    if([url.host isEqualToString:deeplink]){
        self.tabBarController.selectedIndex = 0;
    }
    else if([url.host isEqualToString:mycartHost]){
        self.tabBarController.selectedIndex = 1;
    }
    
    else if([url.host isEqualToString:accountHost]){
        _tabBarController.selectedIndex = 2;
    }
    else{
        NSLog(@"UNMATCHED: %@",url);
    }
}


- (void)sceneDidDisconnect:(UIScene *)scene {
    // Called as the scene is being released by the system.
    // This occurs shortly after the scene enters the background, or when its session is discarded.
    // Release any resources associated with this scene that can be re-created the next time the scene connects.
    // The scene may re-connect later, as its session was not necessarily discarded (see `application:didDiscardSceneSessions` instead).
}


- (void)sceneDidBecomeActive:(UIScene *)scene {
    // Called when the scene has moved from an inactive state to an active state.
    // Use this method to restart any tasks that were paused (or not yet started) when the scene was inactive.
}


- (void)sceneWillResignActive:(UIScene *)scene {
    // Called when the scene will move from an active state to an inactive state.
    // This may occur due to temporary interruptions (ex. an incoming phone call).
}


- (void)sceneWillEnterForeground:(UIScene *)scene {
    // Called as the scene transitions from the background to the foreground.
    // Use this method to undo the changes made on entering the background.
}


- (void)sceneDidEnterBackground:(UIScene *)scene {
    // Called as the scene transitions from the foreground to the background.
    // Use this method to save data, release shared resources, and store enough scene-specific state information
    // to restore the scene back to its current state.
}


@end

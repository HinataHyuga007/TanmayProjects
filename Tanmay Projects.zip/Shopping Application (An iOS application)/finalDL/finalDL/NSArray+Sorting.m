//
//  NSArray+Sorting.m
//  ProductShopping
//
//  Created by Tanmay Dhawale on 24/03/23.
//

#import "NSArray+Sorting.h"
#import "Model.h"
@implementation NSArray (Sorting)
- (NSArray *)sortedArrayByProductPrice{
    return [self sortedArrayUsingComparator:^NSComparisonResult(Model *obj1, Model *obj2) {
        if ([obj1.price integerValue] < [obj2.price integerValue]) {
            return NSOrderedAscending;
        } else if ([obj1.price integerValue] > [obj2.price integerValue]) {
            return NSOrderedDescending;
        } else {
            return NSOrderedSame;
        }
    }];
}
- (NSArray *)sortedArrayByProductCategory{
    return [self sortedArrayUsingComparator:^NSComparisonResult(Model *obj1, Model *obj2) {
        if ([obj1.productCategory integerValue] < [obj2.productCategory integerValue]) {
            return NSOrderedAscending;
        } else if ([obj1.productCategory integerValue] > [obj2.productCategory integerValue]) {
            return NSOrderedDescending;
        } else {
            return NSOrderedSame;
        }
    }];
}

@end


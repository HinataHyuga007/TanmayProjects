//
//  SceneDelegate.h
//  finalDL
//
//  Created by Tanmay Dhawale on 30/03/23.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;
@property (strong, nonatomic) UITabBarController *tabBarController;


@end


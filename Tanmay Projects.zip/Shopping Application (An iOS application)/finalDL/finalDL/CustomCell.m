//
//  CustomCell.m
//  ProductShopping
//
//  Created by Tanmay Dhawale on 19/03/23.
//

#import "CustomCell.h"
#import "FirstViewController.h"
#import "Foundation/Foundation.h"
@implementation CustomCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    self.backgroundColor = UIColor.grayColor;
    
    if (self) {
        
        //self.productTitlesArray = [[NSMutableArray alloc] init];
        self.layer.borderColor = [UIColor blueColor].CGColor;
        self.layer.borderWidth = 1.0;
        self.productImageView = [[UIImageView alloc] initWithFrame:CGRectZero];
        self.productImageView.translatesAutoresizingMaskIntoConstraints = NO;
        self.productImageView.clipsToBounds = YES;
        [self.contentView addSubview:self.productImageView];
        
        self.priceLabel = [[UILabel alloc] init];
        self.priceLabel.translatesAutoresizingMaskIntoConstraints = NO;
        [self.contentView addSubview:self.priceLabel];
        
        self.productNameLabel = [[UILabel alloc] init];
        self.productNameLabel.translatesAutoresizingMaskIntoConstraints = NO;
        [self.contentView addSubview:self.productNameLabel];
        
        self.descriptionLabel = [[UILabel alloc] init];
        self.descriptionLabel.translatesAutoresizingMaskIntoConstraints = NO;
        [self.contentView addSubview:self.descriptionLabel];
        self.descriptionLabel.numberOfLines = 0;
        self.productNameLabel.textColor = UIColor.whiteColor;
        self.productCategoryLabel.textColor = UIColor.whiteColor;
        self.descriptionLabel.textColor = UIColor.blackColor;
        self.priceLabel.textColor = UIColor.blackColor;
        
        
        
        self.productCategoryLabel = [[UILabel alloc] init];
        self.productCategoryLabel.translatesAutoresizingMaskIntoConstraints = NO;
        [self.contentView addSubview:self.productCategoryLabel];
        self.productImageView.backgroundColor = UIColor.grayColor;
        self.descriptionLabel.numberOfLines = 0;
        
        self.additionCart = [UIButton buttonWithType:UIButtonTypeSystem];
        self.additionCart.backgroundColor = UIColor.blueColor;
        self.additionCart.tintColor = UIColor.whiteColor;
        [self.additionCart setTitle:@"Add +" forState:UIControlStateNormal];
        self.additionCart.titleLabel.textAlignment = NSTextAlignmentLeft;
        self.additionCart.titleLabel.textColor = UIColor.whiteColor;
        self.additionCart.translatesAutoresizingMaskIntoConstraints = NO;
        FirstViewController *fc = [[FirstViewController alloc]init];
        [self.additionCart addTarget:fc action:@selector(addTitle:) forControlEvents:UIControlEventTouchUpInside];
        [self.contentView addSubview: self.additionCart];
        
        [NSLayoutConstraint activateConstraints:@[
            //[self.heightAnchor constraintEqualToConstant:200],
            [self.productImageView.leadingAnchor constraintEqualToAnchor:self.contentView.leadingAnchor],
            [self.productImageView.topAnchor constraintEqualToAnchor:self.contentView.topAnchor],
            [self.productImageView.bottomAnchor constraintEqualToAnchor:self.contentView.bottomAnchor],
            [self.productImageView.widthAnchor constraintEqualToConstant:170],
            [self.priceLabel.leadingAnchor constraintEqualToAnchor:self.productImageView.trailingAnchor constant:10],
            [self.priceLabel.topAnchor constraintEqualToAnchor:self.contentView.topAnchor constant:10],
            [self.priceLabel.bottomAnchor constraintEqualToAnchor:self.priceLabel.topAnchor constant:20],
            [self.productNameLabel.leadingAnchor constraintEqualToAnchor:self.priceLabel.leadingAnchor],
            [self.productNameLabel.topAnchor constraintEqualToAnchor:self.priceLabel.bottomAnchor constant:10],
            [self.productNameLabel.bottomAnchor constraintEqualToAnchor:self.productNameLabel.topAnchor constant:25],
            [self.descriptionLabel.leadingAnchor constraintEqualToAnchor:self.priceLabel.leadingAnchor],
            [self.descriptionLabel.topAnchor constraintEqualToAnchor:self.productNameLabel.bottomAnchor constant:10],
            [self.descriptionLabel.bottomAnchor constraintEqualToAnchor:self.descriptionLabel.topAnchor constant:70],
            [self.descriptionLabel.trailingAnchor constraintEqualToAnchor:self.contentView.trailingAnchor],
            [self.productCategoryLabel.leadingAnchor constraintEqualToAnchor:self.priceLabel.leadingAnchor constant:10],
            [self.productCategoryLabel.topAnchor constraintEqualToAnchor:self.descriptionLabel.bottomAnchor constant:10],
            [self.productCategoryLabel.bottomAnchor constraintEqualToAnchor:self.contentView.bottomAnchor ],
            [self.productCategoryLabel.trailingAnchor constraintEqualToAnchor:self.contentView.trailingAnchor constant:-95],
            
            [self.additionCart.leadingAnchor constraintEqualToAnchor:self.productCategoryLabel.trailingAnchor constant:10],
            [self.additionCart.topAnchor constraintEqualToAnchor:self.productCategoryLabel.topAnchor],
            [self.additionCart.trailingAnchor constraintEqualToAnchor:self.contentView.trailingAnchor],
            [self.additionCart.bottomAnchor constraintEqualToAnchor:self.productCategoryLabel.bottomAnchor]
        
        ]];
    }
    self.priceLabel.adjustsFontForContentSizeCategory = YES;
    self.priceLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
    self.descriptionLabel.adjustsFontForContentSizeCategory = YES;
    self.descriptionLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
    self.productNameLabel.adjustsFontForContentSizeCategory = YES;
    self.productNameLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
    self.productCategoryLabel.adjustsFontForContentSizeCategory = YES;
    self.productCategoryLabel.font = [UIFont preferredFontForTextStyle:UIFontTextStyleBody];
    
    return self;
}



@end


//
//  ThirdViewController.m
//  DeepLinking
//
//  Created by Tanmay Dhawale on 30/03/23.
//

#import <Foundation/Foundation.h>
#import"ThirdViewController.h"
@interface ThirdViewController ()
@property (nonatomic, strong) UIImageView *profileImageView;
@property (nonatomic, strong) UILabel *nameLabel;
@property (nonatomic, strong) UILabel *emailLabel;



@end

@implementation ThirdViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setTitle:@"Account"];
    
    // Set the background color
        [self.view setBackgroundColor:[UIColor whiteColor]];
        
        // Create the profile image view
        self.profileImageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"naruto.jpeg"]];
    self.profileImageView.backgroundColor = UIColor.magentaColor;
        [self.profileImageView setContentMode:UIViewContentModeScaleAspectFit];
        [self.profileImageView setTranslatesAutoresizingMaskIntoConstraints:NO];
        [self.view addSubview:self.profileImageView];
        
        // Create the name label
        self.nameLabel = [[UILabel alloc] init];
        [self.nameLabel setText:@"Naruto Uzumaki"];
        [self.nameLabel setFont:[UIFont systemFontOfSize:24.0]];
        [self.nameLabel setTextAlignment:NSTextAlignmentCenter];
        [self.nameLabel setTranslatesAutoresizingMaskIntoConstraints:NO];
        [self.view addSubview:self.nameLabel];
        
        // Create the email label
        self.emailLabel = [[UILabel alloc] init];
        [self.emailLabel setText:@"naruto.hokage@gmail.com"];
        [self.emailLabel setFont:[UIFont systemFontOfSize:18.0]];
        [self.emailLabel setTextAlignment:NSTextAlignmentCenter];
        [self.emailLabel setTranslatesAutoresizingMaskIntoConstraints:NO];
        [self.view addSubview:self.emailLabel];
        
        // Set up Auto Layout constraints
        [NSLayoutConstraint activateConstraints:@[
            [self.profileImageView.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],
            [self.profileImageView.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor constant:16.0],
            [self.profileImageView.widthAnchor constraintEqualToConstant:128.0],
            [self.profileImageView.heightAnchor constraintEqualToConstant:128.0],
            [self.nameLabel.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],
            [self.nameLabel.topAnchor constraintEqualToAnchor:self.profileImageView.bottomAnchor constant:16.0],
            [self.emailLabel.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],
            [self.emailLabel.topAnchor constraintEqualToAnchor:self.nameLabel.bottomAnchor constant:8.0]
        ]];
}

@end
